const API_KEY = '?api_key=cdb6e4fe4726f8b1dffbdff2eb676e52';
const BASE_URL = 'https://api.themoviedb.org/3';
const API_URL = 'https://api.themoviedb.org/3/genre/movie/list';
