const API_KEY = '?api_key=cdb6e4fe4726f8b1dffbdff2eb676e52';
const BASE_URL = 'https://api.themoviedb.org/3';
const API_URL = 'https://api.themoviedb.org/3/genre/movie/list';
const MOVIE_PATH = 'https://api.themoviedb.org/3/movie/334543';
const MOVIE_TOP_RATED = 'https://api.themoviedb.org/3/movie/top_rated?api_key=cdb6e4fe4726f8b1dffbdff2eb676e52&language=en-US&page=1';
const DISCOVER = 'https://api.themoviedb.org/3/discover/movie';
const POPULAR_ACTION = '&sort_by=popularity.desc&page=1&with_genres=%22action%22';
const YEAR_1975 = '&page=5&year=1975';
